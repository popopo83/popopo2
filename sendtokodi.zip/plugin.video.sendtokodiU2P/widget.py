# -*- coding: utf-8 -*-
import os
import sys
import xbmc
import xbmcvfs
import xbmcaddon
import xbmcgui
import xbmcplugin
import time
from medias import Media, TMDB
import sqlite3

def extractIdInVu(t="movies"):
    cnx = sqlite3.connect(xbmcvfs.translatePath('special://home/userdata/addon_data/plugin.video.sendtokodiU2P/bookmark.db'))
    cur = cnx.cursor()
    cur.execute("""CREATE TABLE IF NOT EXISTS movie(
      `id`    INTEGER PRIMARY KEY,
      numId INTEGER,
      pos REAL,
      tt REAL,
      UNIQUE (numId))
        """)
    cnx.commit()
    cur.execute("""CREATE TABLE IF NOT EXISTS tvshow2(
      `id`    INTEGER PRIMARY KEY,
      numId INTEGER,
      pos REAL,
      tt REAL,
      saison INTEGER,
      episode INTEGER,
      UNIQUE (numId, saison, episode))
        """)
    cnx.commit()
    if t == "movies":
        sql = "SELECT numId FROM movie"
    else:
        sql = "SELECT numId FROM tvshow2"
    cur.execute(sql)
    listes = [x[0] for x in cur.fetchall() if x]
    cur.close()
    cnx.close()
    return listes

def extractFavs(t="movies"):
    cnx = sqlite3.connect(xbmcvfs.translatePath('special://home/userdata/addon_data/plugin.video.sendtokodiU2P/bookmark.db'))
    cur = cnx.cursor()
    cur.execute("""CREATE TABLE IF NOT EXISTS favs(
      `id`    INTEGER PRIMARY KEY,
      numId INTEGER,
      type TEXT,
      UNIQUE (numId))
        """)
    cnx.commit()
    sql = "SELECT numId FROM favs WHERE type=?"
    cur.execute(sql, (t, ))
    listes = [x[0] for x in cur.fetchall() if x]
    cur.close()
    cnx.close()
    return listes

def ajoutFavs(numId, t):
    cnx = sqlite3.connect(xbmcvfs.translatePath('special://home/userdata/addon_data/plugin.video.sendtokodiU2P/bookmark.db'))
    cur = cnx.cursor()
    cur.execute("""CREATE TABLE IF NOT EXISTS favs(
      `id`    INTEGER PRIMARY KEY,
      numId INTEGER,
      type TEXT,
      UNIQUE (numId))
        """)
    cnx.commit()
    sql = "REPLACE INTO favs (numId, type) VALUES (?, ?)"
    cur.execute(sql, (numId, t, ))
    cnx.commit()
    cur.close()
    cnx.close()

def supFavs(numId, t):
    cnx = sqlite3.connect(xbmcvfs.translatePath('special://home/userdata/addon_data/plugin.video.sendtokodiU2P/bookmark.db'))
    cur = cnx.cursor()
    cur.execute("""CREATE TABLE IF NOT EXISTS favs(
      `id`    INTEGER PRIMARY KEY,
      numId INTEGER,
      type TEXT,
      UNIQUE (numId))
        """)
    cnx.commit()
    sql = "DELETE FROM favs WHERE numId=? AND type=?"
    cur.execute(sql, (numId, t, ))
    cnx.commit()
    cur.close()
    cnx.close()
    
def supView(numId, t):
    cnx = sqlite3.connect(xbmcvfs.translatePath('special://home/userdata/addon_data/plugin.video.sendtokodiU2P/bookmark.db'))
    cur = cnx.cursor()
    cur.execute("""CREATE TABLE IF NOT EXISTS movie(
      `id`    INTEGER PRIMARY KEY,
      numId INTEGER,
      pos REAL,
      tt REAL,
      UNIQUE (numId))
        """)
    cnx.commit()
    cur.execute("""CREATE TABLE IF NOT EXISTS tvshow2(
      `id`    INTEGER PRIMARY KEY,
      numId INTEGER,
      pos REAL,
      tt REAL,
      saison INTEGER,
      episode INTEGER,
      UNIQUE (numId, saison, episode))
        """)
    cnx.commit()
    if t == "movies":
        sql = "DELETE FROM movie WHERE numId=?"
    else:
        sql = "DELETE FROM tvshow2 WHERE numId=?"
    cur.execute(sql, (numId, ))
    cnx.commit()
    cur.close()
    cnx.close()
    
def extractListe():
    cnx = sqlite3.connect(xbmcvfs.translatePath('special://home/userdata/addon_data/plugin.video.sendtokodiU2P/bookmark.db'))
    cur = cnx.cursor()
    cur.execute("""CREATE TABLE IF NOT EXISTS listes(
      `id`    INTEGER PRIMARY KEY,
      title TEXT,
      sql TEXT,
      type TEXT,
      UNIQUE (title))
        """)
    cnx.commit()
    sql = "SELECT title FROM listes"
    cur.execute(sql)
    listes = [x[0] for x in cur.fetchall() if x]
    cur.close()
    cnx.close()
    return listes
    
def supListe(liste):
    cnx = sqlite3.connect(xbmcvfs.translatePath('special://home/userdata/addon_data/plugin.video.sendtokodiU2P/bookmark.db'))
    cur = cnx.cursor()
    cur.execute("""CREATE TABLE IF NOT EXISTS listes(
      `id`    INTEGER PRIMARY KEY,
      title TEXT,
      sql TEXT,
      type TEXT,
      UNIQUE (title))
        """)
    cnx.commit()
    for l in liste:
        sql = "DELETE FROM listes WHERE title=?"
        cur.execute(sql, (l, ))
    cnx.commit()    
    cur.close()
    cnx.close()
   
def getListe(title):
    cnx = sqlite3.connect(xbmcvfs.translatePath('special://home/userdata/addon_data/plugin.video.sendtokodiU2P/bookmark.db'))
    cur = cnx.cursor()
    cur.execute("""CREATE TABLE IF NOT EXISTS listes(
      `id`    INTEGER PRIMARY KEY,
      title TEXT,
      sql TEXT,
      type TEXT,
      UNIQUE (title))
        """)
    cnx.commit()
    sql = "SELECT sql FROM listes WHERE title=?" 
    cur.execute(sql, (title, ))
    requete  = cur.fetchone()[0]
    cur.close()
    cnx.close()
    return requete

def genre(key, typM="movie"):
    mdb = TMDB(key)
    tabGenre = mdb.getGenre(typM=typM)
    dialog = xbmcgui.Dialog()
    genres = dialog.multiselect("Selectionner le/les genre(s)", tabGenre, preselect=[])
    if genres:
        genresOk = " or ".join(["m.genre LIKE '%%%s%%'" %tabGenre[x] for x in genres])
        return "(" + genresOk + ")"
    else:
        return ""


def year():
    dialog = xbmcgui.Dialog()
    d = dialog.input("Entrer Année => 2010 / Groupe d'années => 2010:2014", type=xbmcgui.INPUT_ALPHANUM)
    if d:
        an = d.split(":")
    if len(an) == 1:
        anOk = " m.year={}".format(an[0])
    else:
        anOk = " m.year>={} and m.year<={}".format(an[0], an[1])

    return anOk

def popu():
    dialog = xbmcgui.Dialog()
    d = dialog.input("Note inférieur à 9 => <9 \nNotes entre 7.5 et 9 => 7.5:9", type=xbmcgui.INPUT_ALPHANUM)
    if d:
        an = d.split(":")
    if len(an) == 1:
        anOk = " m.popu{}".format(an[0])
    else:
        anOk = " (m.popu>{} and m.popu<{})".format(an[0], an[1])

    return anOk

def contenuFilm():
    typContenu = "m.numId NOT IN (SELECT sp.numId FROM movieFamille as sp WHERE sp.famille == '#Spectacles') AND genre NOT LIKE '%%Documentaire%%' AND genre NOT LIKE '%%Animation%%' AND genre != 'Musique' AND "
    return typContenu
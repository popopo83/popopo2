# -*- coding: utf-8 -*-
#$pyFunction
def GetLSProData(page_data,Cookie_Jar,m):
  try:
    import xbmc
    file = xbmc.translatePath("special://profile/addon_data/plugin.video.boxozone/favoris-boxofilm.f2p")
    f = open(file,"r")
    mesfavoris = f.read()
    f.close()
    if "<id>banlieue-13-2004</id>" in mesfavoris:
      return "[COLORlightpink][B]Retirer des favoris Boxofilms[/B][/COLOR]"
    else : return "[B]Ajouter a mes favoris Boxofilms[/B]"
  except: return "[B]Ajouter a mes favoris Boxofilms[/B]"
    

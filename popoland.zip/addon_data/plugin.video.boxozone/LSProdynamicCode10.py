# -*- coding: utf-8 -*-
#$pyFunction
import re
def GetLSProData(page_data,Cookie_Jar,m,chain = "vo"):
 truc=chain.replace("vf","[COLOR lightblue]VF[/COLOR]").replace("vo","[COLOR lightgreen]VOSTFR[/COLOR]");return truc

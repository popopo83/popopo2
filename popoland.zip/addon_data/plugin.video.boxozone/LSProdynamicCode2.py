# -*- coding: utf-8 -*-
#$pyFunction

def GetLSProData(page_data,Cookie_Jar,m):
	import xbmcgui,time
	wdlg = xbmcgui.WindowDialog()
	h = wdlg.getHeight();w = wdlg.getWidth()
	contenu = "[B][UPPERCASE]BOXOFILMS[/UPPERCASE][/B]    [COLORgold]The Postcard Killings[/COLOR]"

	img = xbmcgui.ControlImage(0, 70, w, h, "http://www.eos.to/posters/the-postcard-killings-2017-backdrop.jpg", 1 )
	imgc = xbmcgui.ControlImage(0, 70, w, h, "http://www.eos.to/posters/the-postcard-killings-2017-backdrop.jpg".replace("backdrop","small"), 1 )
	imgb = xbmcgui.ControlImage(0, 70, w, h, "http://www.eos.to/posters/the-postcard-killings-2017-backdrop.jpg".replace("backdrop","big"), 1 )
	
	noir = xbmcgui.ControlImage(0, 0, 1280, 780, "http://pibox.alwaysdata.net/img/noir.jpeg", 1 )
	wdlg.addControl(noir)
	wdlg.addControl(imgc)
	wdlg.addControl(imgb)
	wdlg.addControl(img)
	wdlg.addControl(xbmcgui.ControlLabel(20, 20, 1280, 720, contenu, alignment = 0x00000008, font="font32_title"))
	wdlg.show()
	
	time.sleep(0.3)
	
	
	
	
	dialog = xbmcgui.Dialog()
	dialog.textviewer("[B]BOXOFILMS[/B]  -  Infos Du Film    ", "[B][UPPERCASE]The Postcard Killings[/UPPERCASE][/B] (2017)[COLORgold][CR][COLORlightblue][I]Policier, Thriller, Mystère, Crime, Drame[/I][/COLOR][CR][COLORgrey]Titre original : [/COLOR]The Postcard Killings (2020)[CR][COLORgrey]Note imdb : [/COLOR]5.7/10 (Nb de Votes : 3 425)[COLORgrey][CR]Duree du film : [/COLOR]1h 44min[/COLOR][CR][COLOR grey]Origine: Allemagne[CR]Realisateur: Danis Tanović[CR]Acteurs: Jeffrey Dean Morgan, Cush Jumbo, Joachim Król, Famke Janssen[CR]Note: 6,4/10[/COLOR][CR][CR]Un inspecteur de New York enquête sur une série de meurtres atroces touchant des couples européens. Le meurtrier envoie des cartes postales aléatoirement à des journalistes locaux, chacune annonçant le prochain crime.[CR][CR] [COLORgold]*Toutes les infos en jaune proviennent d'une recherche automatique et peuvent exeptionellement ne pas correspondre au bon film.[/COLOR]")

# -*- coding: utf-8 -*-
import json
import os
import sys
import xbmc
import xbmcvfs
import xbmcaddon
import xbmcgui
import xbmcplugin
import requests
import io
import unicodedata
import re
import ast
import sqlite3
import shutil
import time
import imp
from pastebin import Pastebin
import zipfile
import threading
import datetime

try:
    # Python 3
    from urllib.parse import parse_qsl
except ImportError:
    from urlparse import parse_qsl
try:
    # Python 3
    from urllib.parse import unquote, urlencode
    unichr = chr
except ImportError:
    # Python 2
    from urllib import unquote, urlencode
try:
    # Python 3
    from html.parser import HTMLParser
except ImportError:
    # Python 2
    from HTMLParser import HTMLParser

#import cryptage.pyc
pyVersion = sys.version_info.major
import imp
if pyVersion == 2:
    moduleC = xbmc.translatePath("special://home/addons/plugin.video.sendtokodiU2P/pasteCrypt2.pyc")
else:
    moduleC = xbmcvfs.translatePath("special://home/addons/plugin.video.sendtokodiU2P/pasteCrypt3.pyc")
cryptage = imp.load_compiled("cryptage", moduleC)
#import cryptPaste  as cryptage


class replacement_stderr(sys.stderr.__class__):
    def isatty(self): return False

sys.stderr.__class__ = replacement_stderr


def debug(content):
    log(content, xbmc.LOGDEBUG)


def notice(content):
    log(content, xbmc.LOGINFO)



def log(msg, level=xbmc.LOGINFO):
    addon = xbmcaddon.Addon()
    addonID = addon.getAddonInfo('id')
    xbmc.log('%s: %s' % (addonID, msg), level)


def linkDownload1Fichier(key, linkUrl):
    params = {
            'url' : linkUrl,
            'inline' : 0,
            'cdn' : 0,
            'restrict_ip':  0,
            'no_ssl' : 0,
            }
    url = 'https://api.1fichier.com/v1/download/get_token.cgi'
    r = requests.post(url, json=params, headers={'Authorization':'Bearer {}'.format(key),'Content-Type':'application/json'})
    try:
        o = r.json()
    except JSONDecodeError:
        pass
    message = ""
    url = ""
    if 'status' in o:
        if o['status'] != 'OK':
            message = r.json()['message']
            o['url'] = ""
        return o["url"], message

    else:
        #key out => No such user
        return url, message

def showInfoNotification(message):
    xbmcgui.Dialog().notification("U2Pplay", message, xbmcgui.NOTIFICATION_INFO, 5000)

def showErrorNotification(message):
    xbmcgui.Dialog().notification("U2Pplay", message,
                                  xbmcgui.NOTIFICATION_ERROR, 5000)

def getkeyUpto():
    addon = xbmcaddon.Addon("plugin.video.sendtokodiU2P")
    Apikey = addon.getSetting("keyupto")
    #notice("apikey Upto: %s" %Apikey)

    if not Apikey:
        dialog = xbmcgui.Dialog()
        d = dialog.input("ApiKey UptoBox: ", type=xbmcgui.INPUT_ALPHANUM)
        #notice(d)
        addon.setSetting(id="keyupto", value=d)
        key = d
    else:
        key = Apikey
    return key

def getkey1fichier():
    addon = xbmcaddon.Addon("plugin.video.sendtokodiU2P")
    Apikey = addon.getSetting("key1fichier")

    if not Apikey:
        dialog = xbmcgui.Dialog()
        d = dialog.input("ApiKey 1fichier: ", type=xbmcgui.INPUT_ALPHANUM)
        addon.setSetting(id="key1fichier", value=d)
        key = d
    else:
        key = Apikey
    return key

def getresos():
    addon = xbmcaddon.Addon("plugin.video.sendtokodiU2P")
    resos = addon.getSetting("resos")
    try:
        resos, timing =  resos.split("-")
        resos = [x.strip() for x in resos.split("=")[1].split(",")]
        timing = timing.split("=")[1]
    except:
        resos = ("720", "1080", "2160")
        timing = 0
    return resos, timing

def getkeyAlldebrid():
    addon = xbmcaddon.Addon("plugin.video.sendtokodiU2P")
    Apikey = addon.getSetting("keyalldebrid")
    return Apikey

def getkeyRealdebrid():
    addon = xbmcaddon.Addon("plugin.video.sendtokodiU2P")
    Apikey = addon.getSetting("keyrealdebrid")
    return Apikey

def gestionBD(*argvs):
    cnx = sqlite3.connect(xbmcvfs.translatePath('special://home/addons/plugin.video.sendtokodiU2P/resources/serie.db'))
    cur = cnx.cursor()
    cur.execute("""CREATE TABLE IF NOT EXISTS serie(
                      `id`    INTEGER PRIMARY KEY,
                      numId TEXT,
                      title TEXT,
                      saison TEXT,
                      reso TEXT,
                      pos INTEGER,
                      UNIQUE (title, saison))
                        """)
    cnx.commit()
    if argvs[0] == "update":
        cur.execute("REPLACE INTO serie (numId, title, saison, reso, pos) VALUES (?, ?, ?, ?, ?)", argvs[1:])
        cnx.commit()
        return True
    elif argvs[0] == "get":
        cur.execute("SELECT reso FROM serie WHERE title=? AND saison=?", argvs[1:])
        reso = cur.fetchone()
        return reso
    elif argvs[0] == "last":
        cur.execute("SELECT numId, title, saison, reso FROM serie ORDER BY id DESC LIMIT 1")
        liste = cur.fetchone()
        if liste:
            return liste
        else:
            return ["", "", "", ""]
    cur.close()
    cnx.close()


def getParams(paramstring):

    result = {}
    paramstring = paramstring.split("*")

    # ===================================================================== resos ===========================================================
    resos, timing = getresos()
    histoReso = None
    cr = cryptage.Crypt()
    dictResos = cr.extractReso([(x.split("#")[0].split("@")[0], x.split("#")[0].split("@")[1]) for x in paramstring])
    dictResos = {x.split("#")[0].split("@")[1]: dictResos[x.split("#")[0].split("@")[1]] if dictResos[x.split("#")[0].split("@")[1]] else x.split("#")[1] for x in paramstring}
    typMedia = xbmc.getInfoLabel('ListItem.DBTYPE')
    if not typMedia:
        xbmc.executebuiltin("Dialog.Close(busydialog)")
        xbmc.sleep(500)
        typMedia = xbmc.getInfoLabel('ListItem.DBTYPE')
    notice("type media " + typMedia)
    notice(xbmc.getInfoLabel('ListItem.DBID'))
    
    if typMedia != "movie":
        title = xbmc.getInfoLabel('ListItem.TVShowTitle')
        saison = xbmc.getInfoLabel('ListItem.Season')
        #notice("title " + xbmc.getInfoLabel('Player.Title'))
        if xbmc.Player().isPlaying():
            infoTag = xbmc.Player().getVideoInfoTag()
            title = infoTag.getTVShowTitle()
            saison = infoTag.getSeason()
        notice("serie" + title)
        histoReso = None
        if title:
            idDB = xbmc.getInfoLabel('ListItem.DBID')
            histoReso = gestionBD("get", title, saison)
            notice("histo %s" %histoReso)
        else:
            liste = gestionBD("last")
            if liste:
                idDB, title, saison, reso = liste
                histoReso = (reso, )

    pos = 0
    if histoReso and histoReso[0]:
        resos = [histoReso[0]] + resos
        timing = 2
    try:
        for reso in resos:
            notice(reso)
            for i, lien in enumerate(paramstring):
                if reso in dictResos[lien.split("#")[0].split("@")[1]]:
                    pos = i
                    raise StopIteration
    except StopIteration: pass
    # ========================================================================================================================================

    selected = 0
    if len(paramstring) == 1:
        result['url'] = paramstring[0].split("#")[0]
    else:
        dialog = xbmcgui.Dialog()
        try:
            tabNomLien = ["Lien N° %d (%s)" %(i + 1, dictResos[x.split("#")[0].split("@")[1]]) for i, x in enumerate(paramstring)]
        except:
            tabNomLien = ["Lien N° %d (ind)" %(i + 1) for i, x in enumerate(paramstring)]
        selected = dialog.select("Choix lien", tabNomLien, int(timing) * 1000, pos)
        if selected != -1:
            result['url'] = paramstring[selected].split("#")[0]
        else:
            return

    reso = dictResos[paramstring[selected].split("#")[0].split("@")[1]]
    if typMedia != "movie" and title:
        gestionBD("update", idDB, title, saison, reso, pos)

    # debridage
    ApikeyAlldeb = getkeyAlldebrid()
    ApikeyRealdeb = getkeyRealdebrid()
    if ApikeyAlldeb:
        erreurs = ["AUTH_MISSING_AGENT", "AUTH_BAD_AGENT", "AUTH_MISSING_APIKEY", "AUTH_BAD_APIKEY"]
        urlDedrid, status = cr.resolveLink(result['url'].split("@")[0], result['url'].split("@")[1], keyAllD=ApikeyAlldeb)
        result['url'] = urlDedrid.strip()
        if status in erreurs:
                addon = xbmcaddon.Addon("plugin.video.sendtokodiU2P")
                addon.setSetting(id="keyalldebrid", value="")
    elif ApikeyRealdeb:
        urlDedrid, status = cr.resolveLink(result['url'].split("@")[0], result['url'].split("@")[1], keyRD=ApikeyRealdeb)
        result['url'] = urlDedrid.strip()
        if status == "err":
                addon = xbmcaddon.Addon("plugin.video.sendtokodiU2P")
                addon.setSetting(id="keyrealdebrid", value="")
    else:
        urlDedrid, status = cr.resolveLink(result['url'].split("@")[0], result['url'].split("@")[1], key=getkeyUpto())
        result['url'] = urlDedrid.strip()
        if status == 16:
            addon = xbmcaddon.Addon("plugin.video.sendtokodiU2P")
            addon.setSetting(id="keyupto", value="")

    if result['url'][:-4] in [".mkv", ".mp4"]:
        title = unquote(result['url'][:-4].split("/")[-1])#, encoding='latin-1', errors='replace')
    else:
        title = unquote(result['url'].split("/")[-1])#, encoding='latin-1', errors='replace')
    try:
        title = unicode(title, "utf8", "replace")
    except: pass
    result["title"] = title
    #notice(result)
    return result


def menuPbi():
    xbmcplugin.setPluginCategory(__handle__, "Choix Pbi2kodi")
    for choix in [ ("1. OS", {"action":"os"}, "os.png", "Choix du répertoire de destination des STRM, le chemin correspondant doit exister, sinon crééz le"),
                    ("2. API key Debridage", {"action":"apiConf"}, "debrid.png", 'Alldebrid est prioritaire , et la key Alldebrid doit etre associée avec le lecteur "u2p"'),
                    ("3. Edition Paste", {"action":"ePaste"}, "pastebin.png", "Id AnotePad des Id cryptées."),
                    ("4. Création STRM", {"action":"strms"}, "strm.png", "Création des fichiers STRM et NFO dans le repertoire choisi, c'est un update donc il ne crée que les fichiers inexistants"),
                    ("5. Création GROUPE", {"action":"groupe"}, "groupe.png", "La création doit etre faite aprés le scrap kodi des films et series"),
                    ("6. Clear & Création STRM", {"action":"clearStrms"}, "cStrm.png", "Efface et recrée tous les fichiers STRM"), ("7. Resolutions et default Timing", {"action":"resos"}, "pastebin.png", "Choix des resos prioritaire & timing default lancement média en secondes (0=illimité)"),
                    ("8. Import DataBase", {"action":"bd"}, "strm.png", "Import or Update DATEBASE Kodi (version beta test)"),
                    ("9. Gestion Thumbnails", {"action":"thmn"}, "cStrm.png", "Taille du répertoire thumbnails 7000=800M environ, au dela les plus anciennes seront effacées (0=illimité)"),
                    ("10. Choix Repo", {"action":"choixrepo"}, "pastebin.png", "Choix des catégories à ajouter dans le skin (Estuary)"),
                    ("11. Choix Listes Intelligentes", {"action":"choixliste"}, "pastebin.png", "Choix des listes intelligentes"),]:
        addDirectoryItem(choix[0], isFolder=False, parameters=choix[1], picture=choix[2], texte=choix[3])
    xbmcplugin.endOfDirectory(handle=__handle__, succeeded=True)

def addDirectoryItem(name, isFolder=True, parameters={}, picture="", texte="" ):
    ''' Add a list item to the XBMC UI.'''
    addon = xbmcaddon.Addon("plugin.video.sendtokodiU2P")
    li = xbmcgui.ListItem(label=name)

    li.setInfo('video', {"title": name, 'plot': texte,'mediatype': 'video'})
    li.setArt({'thumb': 'special://home/addons/plugin.video.sendtokodiU2P/resources/png/%s' %picture,
              'icon': addon.getAddonInfo('icon'),
              'fanart': addon.getAddonInfo('fanart')})
    url = sys.argv[0] + '?' + urlencode(parameters)
    return xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=url, listitem=li, isFolder=isFolder)

def selectOS():
    addon = xbmcaddon.Addon("plugin.video.sendtokodiU2P")
    choixOs = ["WIN (D:\\kodiBase\\)", "LIBREELEC (/storage/downloads/Kodi/)",  "ANDROID (/storage/emulated/0/kodiBase/)",  "LINUX (/home/(user)/kodiBase/)", "XBOX (U:\\Users\\UserMgr0\\AppData\\Local\\Packages\\XBMCFoundation.Kodi_4n2hpmxwrvr6p\\LocalState\\userdata\\)", "Mon repertoire"]
    dialogOS = xbmcgui.Dialog()
    selectedOS = dialogOS.select("Choix OS", choixOs)
    if selectedOS != -1:
        if selectedOS == len(choixOs) - 1:
            osVersion = addon.getSetting("osVersion")
            dialogPaste = xbmcgui.Dialog()
            d = dialogPaste.input("Repertoire STRM", type=xbmcgui.INPUT_ALPHANUM, defaultt=osVersion)
            addon.setSetting(id="osVersion", value=d)
        else:
            addon.setSetting(id="osVersion", value=choixOs[selectedOS])

def configKeysApi():
    addon = xbmcaddon.Addon("plugin.video.sendtokodiU2P")
    dictApi = {"Uptobox": ["keyupto", "Key Api Uptobox"], "Alldebrid": ["keyalldebrid", "Key Api Alldebrid"], "RealDebrid": ["keyrealdebrid", "Key Api RealDebrid"]}
    choixApi = list(dictApi.keys())
    dialogApi = xbmcgui.Dialog()
    selectedApi = dialogApi.select("Choix Api", choixApi)
    if selectedApi != -1:
        key = addon.getSetting(dictApi[choixApi[selectedApi]][0])
        d = dialogApi.input(dictApi[choixApi[selectedApi]][1], type=xbmcgui.INPUT_ALPHANUM, defaultt=key)
        addon.setSetting(id=dictApi[choixApi[selectedApi]][0], value=d)

def makeStrms(clear=0):
    pDialog = xbmcgui.DialogProgress()
    pDialog.create('Pbi2kodi', 'Extraction Paste... .')
    addon = xbmcaddon.Addon("plugin.video.sendtokodiU2P")
    osVersion = addon.getSetting("osVersion")
    if "WIN" in osVersion:
        repKodiName = "D:\\kodiBase\\"
    elif "LIBREELEC" in osVersion:
        repKodiName = "/storage/downloads/Kodi/"
    elif "LINUX" in osVersion:
        repKodiName = "/storage/downloads/Kodi/"
    elif "ANDROID" in osVersion:
        repKodiName = "/storage/emulated/0/kodiBase/"
    elif "XBOX" in osVersion:
        repKodiName = "U:\\Users\\UserMgr0\\AppData\\Local\\Packages\\XBMCFoundation.Kodi_4n2hpmxwrvr6p\\LocalState\\userdata\\"
    else:
        repKodiName = osVersion
    lePaste = addon.getSetting("paste")
    dictPaste = idPaste(lePaste)
    for nomRep, tabPaste in dictPaste.items():
        notice(nomRep)
        paramPaste = {"tabIdPbi": tabPaste, "namePbi": 'test', "repKodiName": repKodiName, "clear": clear}
        pbi = Pastebin(**paramPaste)
        pbi.makeMovieNFO(pbi.dictFilmsPaste.values(), clear=clear, progress=pDialog, nomRep=nomRep)
        pDialog.update(0, 'SERIES')
        pbi.makeSerieNFO(pbi.dictSeriesPaste.values(), clear=clear, progress=pDialog, nomRep=nomRep)
        pDialog.update(0, 'ANIMES')
        pbi.makeAnimeNFO(pbi.dictAnimesPaste.values(), clear=clear, progress=pDialog, nomRep=nomRep)
        pDialog.update(0, 'DIVERS')
        pbi.makeDiversNFO(pbi.dictDiversPaste.values(), clear=clear, progress=pDialog, nomRep=nomRep)
    showInfoNotification("strms créés!")

def idPaste(lePaste):
    html_parser = HTMLParser()
    motifAnotepad = r'.*<\s*div\s*class\s*=\s*"\s*plaintext\s*"\s*>(?P<txAnote>.+?)</div>.*'
    rec = requests.get("https://anotepad.com/note/read/" + lePaste, timeout=3)
    r = re.match(motifAnotepad, rec.text, re.MULTILINE|re.DOTALL|re.IGNORECASE)
    tx = r.group("txAnote")
    tx = html_parser.unescape(tx)
    dictLignes = {x.split("=")[0].strip(): [y.strip() for y in x.split("=")[1].split(",")]  for x in tx.splitlines() if x and x[0] != "#"}
    return dictLignes

def editPaste():
    addon = xbmcaddon.Addon("plugin.video.sendtokodiU2P")
    paste = addon.getSetting("paste")
    dialogPaste = xbmcgui.Dialog()
    d = dialogPaste.input("Num AnotePad Pastes", type=xbmcgui.INPUT_ALPHANUM, defaultt=paste)
    addon.setSetting(id="paste", value=d)

def editNbThumbnails():
    addon = xbmcaddon.Addon("plugin.video.sendtokodiU2P")
    paste = addon.getSetting("thumbnails")
    dialogPaste = xbmcgui.Dialog()
    d = dialogPaste.input("Nombre d'images THUMBNAILS conservées (0=illimité)", type=xbmcgui.INPUT_ALPHANUM, defaultt=paste)
    addon.setSetting(id="thumbnails", value=d)


def editResos():
    addon = xbmcaddon.Addon("plugin.video.sendtokodiU2P")
    paste = addon.getSetting("resos")
    dialogPaste = xbmcgui.Dialog()
    d = dialogPaste.input("resos prioritaire & timing", type=xbmcgui.INPUT_ALPHANUM, defaultt=paste)
    addon.setSetting(id="resos", value=d)

def delTag(dataBaseKodi):
    cnx = sqlite3.connect(dataBaseKodi)
    cur = cnx.cursor()
    cur.execute("DELETE FROM tag")
    cur.execute("DELETE FROM tag_link")
    cnx.commit()
    cur.close()
    cnx.close()

def creaGroupe():
    showInfoNotification("Création groupes!")
    addon = xbmcaddon.Addon("plugin.video.sendtokodiU2P")
    osVersion = addon.getSetting("osVersion")
    lePaste = addon.getSetting("paste")
    dictPaste = idPaste(lePaste)
    delTag(__database__)
    for nomRep, tabPaste in dictPaste.items():
        pDialog2 = xbmcgui.DialogProgressBG()
        pDialog2.create('Pbi2kodi', 'Création Groupes (%s)...' %nomRep)
        #notice(nomRep)
        paramPaste = {"tabIdPbi": tabPaste, "namePbi": 'test', "repKodiName": "", "clear": 0}
        pbi = Pastebin(**paramPaste)
        pbi.UpdateGroupe(pbi.dictGroupeFilms, __database__, progress= pDialog2, gr=nomRep)
        #pDialog2.update(10, 'SERIES')
        pbi.UpdateGroupe(pbi.dictGroupeSeries, __database__, mediaType="tvshow", progress= pDialog2, gr=nomRep)
        pDialog2.close()
    showInfoNotification("Groupes créés!")


def getTimeBookmark(numId, dataBaseKodi, typMedia):
    cnx = sqlite3.connect(dataBaseKodi)
    cur = cnx.cursor()
    if typMedia == "movie":
        sql = "SELECT timeInSeconds FROM bookmark WHERE idFile=(SELECT m.idFile FROM movie as m WHERE m.idMovie=%s)" %(numId)
    else:
        sql = "SELECT timeInSeconds FROM bookmark WHERE idFile=(SELECT m.idFile FROM episode as m WHERE m.idEpisode=%s)" %(numId)
    cur.execute(sql)
    seek = [x[0] for x in cur.fetchall() if x]
    cur.close()
    cnx.close()
    if seek:
        return seek[0]
    else:
        return 0

def getSeasonU2P(numId, dataBaseKodi , numEpisode):
    cnx = sqlite3.connect(dataBaseKodi)
    sql = "SELECT c18 FROM episode WHERE c19=(SELECT m.c19 FROM episode as m WHERE m.idEpisode=%s)" %(numId)
    cur = cnx.cursor()
    cur.execute(sql)
    tabEpisodes = sorted([x[0] for x in cur.fetchall() if x])
    cur.close()
    cnx.close()
    return tabEpisodes[int(numEpisode):]


def createListItemFromVideo(video):
    url = video['url']
    title = video['title']
    list_item = xbmcgui.ListItem(title, path=url)
    list_item.setInfo(type='Video', infoLabels={'Title': title})
    return list_item

def correctionBookmark(idfile, typMedia):
    try:
        tt = xbmc.Player().getTotalTime()
        while xbmc.Player().isPlaying():
            t = xbmc.Player().getTime()
            notice(t)
            time.sleep(1)
        cnx = sqlite3.connect(__database__)
        cur = cnx.cursor()
        if typMedia == "movie":
            sql0 =  "UPDATE bookmark SET timeInSeconds=? WHERE idFile=?"
            sql = "REPLACE INTO bookmark (idFile, timeInSeconds, totalTimeInSeconds, thumbNailImage, player, playerState, type) VALUES(?, ?, ?, ?, ?, ?, ? )"
        else:
            sql = "SELECT timeInSeconds FROM bookmark WHERE idFile=(SELECT m.idFile FROM episode as m WHERE m.idEpisode=%s)" %(numId)
        try: 
            cur.execute(sql0, (t, idfile,))
        except sqlite3.Error as er:
            cur.execute(sql, (idfile, t, tt, None, 'VideoPlayer', None, 1,))
        cnx.commit()
        cur.close()
        cnx.close()
    except Exception as e:
        notice("insert bookmark " + e)

def getIDfile(f):
    try:
        cnx = sqlite3.connect(__database__)
        cur = cnx.cursor()
        sql = "SELECT idFile FROM files WHERE strFilename=? AND dateAdded IS NOT NULL"
        cur.execute(sql, (f,))
        return cur.fetchone()[0]
    except Exception as e:
        notice("get infos file " + str(e))

    

def playMedia(params):
    typMedia = xbmc.getInfoLabel('ListItem.DBTYPE')
    if not typMedia:
        xbmc.executebuiltin("Dialog.Close(busydialog)")
        xbmc.sleep(500)
        typMedia = xbmc.getInfoLabel('ListItem.DBTYPE')
    fPlay = sys.argv[0] + sys.argv[2]
    if typMedia != "movie":
        idfile= getIDfile(fPlay)
    else:            
        idfile = xbmc.getInfoLabel('ListItem.DBID')
    notice(xbmc.getInfoLabel('ListItem.Episode'))
    notice(xbmc.getInfoLabel('ListItem.TvShowDBID'))
    notice(xbmc.getInfoLabel('ListItem.PercentPlayed')) 
    notice(xbmc.getInfoLabel('ListItem.EndTimeResume')) 
    notice("fin listem")
    typDB = "non auto"
    result = getParams(params['lien'])
    if result and "url" in result.keys():
        url = str(result['url'])
        showInfoNotification("playing title " + result['title'])
        notice("num id " + str(result))
        notice("handle " + str(__handle__))
        try:
            listIt = createListItemFromVideo(result)
            xbmcplugin.setResolvedUrl(__handle__, True, listitem=listIt) 
            #xbmc.Player().play(url, listIt)
            #xbmc.executebuiltin('PlayMedia(%s)' %url)
        except Exception as e:
            notice(e)
        threading.Thread(target=gestionThumbnails).start()
        count = 0
        time.sleep(2)
        while not xbmc.Player().isPlaying():
            count = count + 1
            if count >= 20:
                return
            else:
                time.sleep(1)
        try:
            infoTag = xbmc.Player().getVideoInfoTag()
            notice(infoTag.getDbId())
            #idfile = infoTag.getDbId()
            notice("idFile " + str(idfile))
            #notice(xbmc.Player().getPlayingFile())
            #typMedia = infoTag.getMediaType()
            #
            seek = getTimeBookmark(idfile,  __database__, typMedia)
        except Exception as e:
            xbmc.Player().pause
            notice(str(e))
            seek = 0

        
        if seek > 0:
            dialog = xbmcgui.Dialog()
            resume = dialog.yesno('Play Video', 'Resume last position?')
            if resume:
                notice(xbmc.getInfoLabel('Player.Title'))
                xbmc.Player().seekTime(int(seek))
        
        #threading.Thread(target=correctionBookmark, args=(idfile, typMedia))
        #importDatabase(debug=0)
        #tx = testDatabase()
        #if tx:
        #    showInfoNotification("New DataBase en ligne  !!!")
        #threading.Thread(target=importDatabase)

        if typDB == "auto":
            tt = xbmc.Player().getTotalTime()
            while xbmc.Player().isPlaying():
                t = xbmc.Player().getTime()
                notice(t)
                time.sleep(1)
            notice(str(typMedia) + str(idfile))
            cnx = sqlite3.connect(__database__)
            cur = cnx.cursor()
            typeM = 1
            if t > 180:
                cur.execute("SELECT idFile FROM bookmark WHERE idFile=?", (idfile,))
                if cur.fetchone():
                    sql0 =  "UPDATE bookmark SET timeInSeconds=? WHERE idFile=?"
                    cur.execute(sql0, (t, idfile,))
                else: 
                    sql0 = "REPLACE INTO bookmark (idFile, timeInSeconds, totalTimeInSeconds, thumbNailImage, player, playerState, type) VALUES(?, ?, ?, ?, ?, ?, ? )"
                    cur.execute(sql0, (idfile, t, tt, None, 'VideoPlayer', None, typeM,))
                 
            cnx.commit()
            cur.close()
            cnx.close()
            notice("ok")
        return

def majLink(dataBaseKodi):
    
    dateTimeObj = datetime.datetime.now()
    timestampStr = dateTimeObj.strftime("%Y-%m-%d %H:%M:%S")
 
    oldRep = '/storage/emulated/0/kodibase'
    #newRep = xbmcvfs.translatePath("special://home/addons/plugin.video.sendtokodiU2P/kodibase")
    newRep, corr = cheminOs()
    cnx = sqlite3.connect(dataBaseKodi)
    cur = cnx.cursor()
    if newRep != "/storage/emulated/0/":
        newRep = os.path.normpath(os.path.join(newRep, "kodibase")) 
        cur.execute("UPDATE path SET strPath = REPLACE(strPath, '%s', '%s')" % (oldRep, newRep))
        cur.execute("UPDATE movie SET c22 = REPLACE(c22, '%s', '%s')" % (oldRep, newRep))
        cur.execute("UPDATE episode SET c18 = REPLACE(c18, '%s', '%s')" % (oldRep, newRep))
        #UPDATE art SET url = REPLACE(url,'smb://my_nas/old_share', 'smb://my_nas/new_share');
        cur.execute("UPDATE tvshow SET c16 = REPLACE(c16, '%s', '%s')" % (oldRep, newRep))
        cur.execute("UPDATE files SET strFilename = REPLACE(strFilename, '%s', '%s'), dateAdded='%s'" % (oldRep, newRep, timestampStr))
        
        if corr:
            cur.execute("UPDATE path SET strPath = REPLACE(strPath,'%s', '%s')" %("/", "\\"))
            cur.execute("UPDATE episode SET c18 = REPLACE(c18,'%s', '%s')" %("/", "\\"))
            cur.execute("UPDATE movie SET c22 = REPLACE(c22,'%s', '%s')" %("/", "\\"))
            cur.execute("UPDATE tvshow SET c16 = REPLACE(c16,'%s', '%s')" %("/", "\\"))
            cur.execute("UPDATE files SET strFilename = REPLACE(strFilename,'%s', '%s')" %("/", "\\"))    
        cnx.commit()

    
    cnx2 = sqlite3.connect(__database__)
    cur2 = cnx2.cursor()
    
    cur2.execute("SELECT * FROM bookmark")
    bookmark = cur2.fetchall()
    try:
        cur.executemany("INSERT INTO bookmark VALUES(?, ?, ?, ?, ?, ?, ?, ?)", bookmark)
        cnx.commit()
    except: pass

    cur2.execute("SELECT * FROM files WHERE lastPlayed OR playCount")
    histoPlay = cur2.fetchall()
    histoPlay = [(x[0], x[1], x[2], x[3] if x[3] and x[3] != 'None' else "", x[4] if x[4] and x[4] != 'None' else "", x[5]) for x in histoPlay]
    #print(histoPlay)
    for h in histoPlay:
        cur.execute("UPDATE files set lastPlayed=?, playCount=? WHERE idFile=? AND idPath=?", (h[4], h[3], h[0], h[1], ))
    cnx.commit()

    cur.close()
    cnx.close()
    cur2.close()
    cnx2.close()

    # ajout sources
    with open(xbmcvfs.translatePath("special://home/userdata/sources.xml"), "r") as f:
        txSources = f.read()
    with open(xbmcvfs.translatePath("special://home/addons/plugin.video.sendtokodiU2P/fileSources.txt"), "r") as f:
        tx = f.read()
        dictSource = {x.split("=")[0]: x.split("=")[1] for x in tx.splitlines()}
    source = """<source>
            <name>{}</name>
            <path pathversion="1">{}</path>
            <allowsharing>true</allowsharing>
        </source>\n"""
    sources = ""
    for k, v in dictSource.items():
        depot = os.path.normpath(v.replace(oldRep, newRep))
        if v.replace(oldRep, newRep) not in txSources:
            sources += source.format(k, depot)
    with open(xbmcvfs.translatePath("special://home/userdata/sources.xml"), "w") as f:
        f.write(txSources.format(**{"sources":sources}))



def cheminOs():
    addon = xbmcaddon.Addon("plugin.video.sendtokodiU2P")
    osVersion = addon.getSetting("osVersion")
    corr = 0
    if "WIN" in osVersion:
        corr = 1
        repKodiName = "D:\\kodiBase\\"
    elif "LIBREELEC" in osVersion:
        repKodiName = "/storage/downloads/"
    elif "LINUX" in osVersion:
        repKodiName = "/storage/downloads/"
    elif "ANDROID" in osVersion:
        repKodiName = "/storage/emulated/0/"
    elif "XBOX" in osVersion:
        corr = 1
        repKodiName = "U:\\Users\\UserMgr0\\AppData\\Local\\Packages\\XBMCFoundation.Kodi_4n2hpmxwrvr6p\\LocalState\\userdata\\"
    else:
        corr = 1
        repKodiName = osVersion
    return repKodiName, corr

def get_size(rep):
    total_size = 0
    for dirpath, dirnames, filenames in os.walk(rep):
        for f in filenames:
            fp = os.path.join(dirpath, f)
            total_size += os.path.getsize(fp)
    return total_size

def gestionThumbnails():
    addon = xbmcaddon.Addon("plugin.video.sendtokodiU2P")
    nbT = addon.getSetting("thumbnails")
    try:
        nbT = int(nbT)
    except:
        nbT = 0
    if nbT > 0:
        dbTexture = xbmcvfs.translatePath("special://home/userdata/Database/Textures13.db")
        repThumb = xbmcvfs.translatePath("special://thumbnails")
        cnx2 = sqlite3.connect(dbTexture)
        cur2 = cnx2.cursor()
        tabFiles = []
        for dirpath, dirs, files in os.walk(repThumb): 
            for filename in files:
                fname = os.path.normpath(os.path.join(dirpath,filename))
                tabFiles.append(fname)
        if len(tabFiles) > 7000:
            tabFiles.sort(key=os.path.getmtime, reverse=True)
            for f in tabFiles[7000:]:
                head ,tail = os.path.split(f)
                cur2.execute("SELECT id FROM texture WHERE cachedurl LIKE '{}'".format("%" + tail + "%"))
                num = cur2.fetchone()
                if num:
                    cur2.execute("DELETE FROM texture WHERE id=?", (num[0],))
                    cur2.execute("DELETE FROM sizes WHERE idtexture=?", (num[0],))
                xbmcvfs.delete(f) 
        cnx2.commit()
        cur2.close()
        cnx2.close()   

def extractNews(numVersion):
    listeNews = []
    if os.path.isfile(xbmcvfs.translatePath('special://home/addons/plugin.video.sendtokodiU2P/resources/u2pBD.bd')):
        cnx = sqlite3.connect(xbmcvfs.translatePath('special://home/addons/plugin.video.sendtokodiU2P/resources/u2pBD.bd'))
        cur = cnx.cursor()
        cur.execute("SELECT strm FROM strms WHERE version>?", (numVersion,))
        listeNews = [x[0] for x in cur.fetchall()]
        cur.close()
        cnx.close()
    return listeNews

def testDatabase(typImport="full"):
    ApikeyAlldeb = getkeyAlldebrid()
    ApikeyRealdeb = getkeyRealdebrid()
    ApikeyUpto = getkeyUpto()
    cr = cryptage.Crypt()
    repAddon = xbmcvfs.translatePath("special://home/addons/plugin.video.sendtokodiU2P/")
    repStrm, _ = cheminOs()
    if ApikeyUpto:
        tx = cr.updateBD(repAddon, t=typImport, key=ApikeyUpto, typkey="upto")
    elif ApikeyAlldeb:
        tx = cr.updateBD(repAddon, t=typImport, key=ApikeyAlldeb, typkey="alldeb")
    elif ApikeyRealdeb:
        tx = cr.updateBD(repAddon, t=typImport, key=ApikeyRealdeb, typkey="realdeb")
    return tx 
    
def importDatabase(typImport="full", debug=1):
    # debridage
    tps = time.time()
    if debug:
        showInfoNotification("Verif Update")
    ApikeyAlldeb = getkeyAlldebrid()
    ApikeyRealdeb = getkeyRealdebrid()
    ApikeyUpto = getkeyUpto()
    cr = cryptage.Crypt()
    repAddon = xbmcvfs.translatePath("special://home/addons/plugin.video.sendtokodiU2P/")
    repStrm, _ = cheminOs()
    if ApikeyUpto:
        tx = cr.updateBD(repAddon, t=typImport, key=ApikeyUpto, typkey="upto")
    elif ApikeyAlldeb:
        tx = cr.updateBD(repAddon, t=typImport, key=ApikeyAlldeb, typkey="alldeb")
    elif ApikeyRealdeb:
        tx = cr.updateBD(repAddon, t=typImport, key=ApikeyRealdeb, typkey="realdeb")
    a = time.time()
    if tx:
        if debug == 0:
            showInfoNotification("Update DataBase en cours, wait ....")
        pDialogBD2 = xbmcgui.DialogProgressBG()
        pDialogBD2.create('U2Pplay', 'Update en cours')
        try:
            shutil.rmtree(os.path.normpath(os.path.join(repStrm, "xml")), ignore_errors=True)
        except: pass
        try:
            shutil.rmtree(os.path.normpath(os.path.join(repStrm, "xsp")), ignore_errors=True)
        except: pass

        if os.path.isfile(xbmcvfs.translatePath('special://home/addons/plugin.video.sendtokodiU2P/version.txt')):
            numVersion = int(open(xbmcvfs.translatePath('special://home/addons/plugin.video.sendtokodiU2P/version.txt'), 'r').readline())
        else:
            numVersion = 0
        
        with zipfile.ZipFile(xbmcvfs.translatePath("special://home/addons/plugin.video.sendtokodiU2P/MyVideos119-U2P.zip"), 'r') as zipObject:
           zipObject.extract("u2pBD.bd", xbmcvfs.translatePath('special://home/addons/plugin.video.sendtokodiU2P/resources/'))
           listeNews = extractNews(numVersion)
           listOfFileNames = zipObject.namelist()
           nbFiles = len(listOfFileNames)
           for i, f in enumerate(listOfFileNames):
                nbGroupe = int((i / float(nbFiles)) * 100.0)
                pDialogBD2.update(nbGroupe, 'U2Pplay', message="verif STRMS")
                if (numVersion == 0 and f[-5:] == ".strm") or f in listeNews:
                    zipObject.extract(f, repStrm)
                elif f[-4:] in [".xml", ".xsp"]: 
                        zipObject.extract(f, repAddon)
                else:
                    if f in ["MyVideos119-U2P.db", "fileSources.txt", "sources.xml", "version.txt"] or f[-4:] in [".xml", ".xsp"]:
                        zipObject.extract(f, repAddon)
        pDialogBD2.close()
        showInfoNotification("Mise en place new database !!!")
        notice("extraction %0.2f" %(time.time() - a))
        a = time.time()
        shutil.move(xbmcvfs.translatePath("special://home/addons/plugin.video.sendtokodiU2P/sources.xml"), xbmcvfs.translatePath("special://home/userdata/sources.xml"))
        majLink(xbmcvfs.translatePath("special://home/addons/plugin.video.sendtokodiU2P/MyVideos119-U2P.db"))
        xbmcvfs.delete(xbmcvfs.translatePath("special://home/addons/plugin.video.sendtokodiU2P/MyVideos119-U2P.zip"))
        shutil.move(xbmcvfs.translatePath("special://home/addons/plugin.video.sendtokodiU2P/MyVideos119-U2P.db"), __database__)
        #xbmcvfs.delete(xbmcvfs.translatePath("special://home/addons/plugin.video.sendtokodiU2P/MyVideos119-U2P.db"))
        showInfoNotification("Update terminée (%d News), restart Kodi" %len(listeNews))
        notice("maj DATABASE %0.2f" %(time.time() - a))
        a = time.time()
    
    else:
        if debug:
            showInfoNotification("Pas d'update")
    if debug:
        showInfoNotification("Durée Update : %d s" %(time.time() - tps))
        gestionThumbnails()
    return
    

def choixRepo():
    repReposFilm = xbmcvfs.translatePath("special://home/addons/plugin.video.sendtokodiU2P/xml/movie/") 
    repCatFilm = xbmcvfs.translatePath("special://home/userdata/library/video/movies/")
    filesRepo = os.listdir(repReposFilm)
    try:
        filesCat = os.listdir(repCatFilm)
    except:
        showInfoNotification("Installer Library Node Editor")
        return
    dialog = xbmcgui.Dialog()
    repos = dialog.multiselect("Selectionner les repos à installer", [x[:-4].replace("_", " ") for x in filesRepo], preselect=[])
    if repos:
        [xbmcvfs.delete(repCatFilm + x) for x in filesRepo if x in filesCat]
        for repo in repos:
            shutil.copy(repReposFilm + filesRepo[repo], repCatFilm + filesRepo[repo]) 
    xbmc.sleep(500)
    xbmc.executebuiltin('ReloadSkin')

def choixliste():
    repListes = xbmcvfs.translatePath("special://home/addons/plugin.video.sendtokodiU2P/xsp/") 
    dictRep = {"Listes intélligentes made in %s" %x: [x] for x in os.listdir(repListes)}
    
    #dictApi = {"Uptobox": ["keyupto", "Key Api Uptobox"], "Alldebrid": ["keyalldebrid", "Key Api Alldebrid"], "RealDebrid": ["keyrealdebrid", "Key Api RealDebrid"]}
    dialogApi = xbmcgui.Dialog()
    choixRep = list(dictRep.keys())
    selectedApi = dialogApi.select("Choix Contrib", choixRep)
    
    if selectedApi != -1:
        contrib = dictRep[choixRep[selectedApi]][0]
        repReposFilm = xbmcvfs.translatePath("special://home/addons/plugin.video.sendtokodiU2P/xsp/%s/" %contrib)  
        repCatFilm = xbmcvfs.translatePath("special://home/userdata/playlists/video/")
        filesRepo = os.listdir(repReposFilm)
        filesCat = os.listdir(repCatFilm)
        dialog = xbmcgui.Dialog()
        repos = dialog.multiselect("Selectionner les listes à installer", [x[:-4].replace("_", " ") for x in filesRepo], preselect=[])
        if repos:
            [xbmcvfs.delete(repCatFilm + x) for x in filesRepo if x in filesCat]
            for repo in repos:
                shutil.copy(repReposFilm + filesRepo[repo], repCatFilm + filesRepo[repo]) 
        xbmc.sleep(500)
        xbmc.executebuiltin('ReloadSkin')

def router(paramstring):
    params = dict(parse_qsl(paramstring))
    if params:
        if params['action'] == 'play':
            playMedia(params)
        elif params['action'] == 'os':
            selectOS()
        elif params['action'] == 'apiConf':
            configKeysApi()
        elif params['action'] == 'strms':
            makeStrms()
        elif params['action'] == 'clearStrms':
            makeStrms(1)
        elif params['action'] == 'ePaste':
            editPaste()
        elif params['action'] == 'thmn':
            editNbThumbnails()
        elif params['action'] == 'groupe':
            creaGroupe()
        elif params['action'] == 'resos':
            editResos()
        elif params['action'] == 'bd':
            importDatabase()
        elif params['action'] == 'choixrepo':
            choixRepo()
        elif params['action'] == 'choixliste':
            choixliste()
        else:
            raise ValueError('Invalid paramstring: {0}!'.format(paramstring))
    else:
        menuPbi()

if __name__ == '__main__':
    nameExploit = sys.platform
    notice(nameExploit)
    # Get the plugin url in plugin:// notation.
    __url__ = sys.argv[0]
    # Get the plugin handle as an integer number.
    __handle__ = int(sys.argv[1])
    #  database video kodi
    if pyVersion == 2:
        bdKodi = "MyVideos116.db"
    else:
        bdKodi = "MyVideos119.db"
    try:
        __database__ = xbmc.translatePath("special://home/userdata/Database/%s" %bdKodi)
    except:
        __database__ = xbmcvfs.translatePath("special://home/userdata/Database/%s" %bdKodi)
    #Deprecated xbmc.translatePath. Moved to xbmcvfs.translatePath
    __repAddon__ = xbmcvfs.translatePath("special://home/addons/plugin.video.sendtokodiU2P/")
    notice(__database__)
    notice(sys.argv)
    #notice(sys.version_info)
    #notice(__url__)
    #notice(__handle__)
    #smb://<nvidiashieldurl>/internal/Android/data/org.xbmc.kodi/files/.kodi/userdata 
    router(sys.argv[2][1:])


